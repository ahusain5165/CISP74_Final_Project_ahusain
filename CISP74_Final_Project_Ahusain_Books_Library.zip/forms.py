"""
Ahmed Husain
Summary:
This file defines the forms used in the Flask application for user registration, login, and book management.
1. `RegistrationForm` allows new users to register with details such as name, login ID, password, and privileges.
2. `LoginForm` is used for user login with login ID and password.
3. `BookForm` is used to manage book details such as title, author, publisher, genre, publication year, and ISBN.

These forms use Flask-WTF for form handling and validation with WTForms.
"""

from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField, PasswordField, SelectField
from wtforms.validators import DataRequired, Optional, Length
from datetime import datetime
from wtforms.validators import NumberRange

class RegistrationForm(FlaskForm):
    """
    This form is used for new user registration. 
    It includes fields for name, login ID, password, and privileges.
    """
    Name = StringField('Name', validators=[DataRequired()])  
    # The Name field requires user input and cannot be left empty.

    LoginID = StringField('Login ID', validators=[DataRequired()])  
    # The Login ID field requires user input and cannot be left empty.

    Password = PasswordField('Password', validators=[DataRequired()])  
    # The Password field requires user input and cannot be left empty.

    Privileges = SelectField('Privileges', choices=[ 
        ('read', 'Read'), 
        ('edit', 'Edit'), 
        ('delete', 'Delete'), 
        ('full', 'Full Control')
    ], validators=[DataRequired()])  
    # The Privileges field is a dropdown with options for user access level and requires selection.

    submit = SubmitField('Register')  
    # The submit button allows the user to submit the form.

class LoginForm(FlaskForm):
    """
    This form is used for user login.
    It includes fields for login ID and password.
    """
    LoginID = StringField('Login ID', validators=[DataRequired()])  
    # The Login ID field requires user input and cannot be left empty.

    password = PasswordField('Password', validators=[DataRequired()])  
    # The Password field requires user input and cannot be left empty.

    submit = SubmitField('Login')  
    # The submit button allows the user to submit the form.

class BookForm(FlaskForm):
    """
    This form is used for managing book details. It includes fields for book title, author, publisher, genre, 
    publication year, and ISBN.
    """
    title = StringField('Title', validators=[DataRequired(), Length(max=100)])
    # The Title field requires user input, and the length is limited to 100 characters.

    author = StringField('Author', validators=[DataRequired(), Length(max=100)])
    # The Author field requires user input, and the length is limited to 100 characters.

    publisher = StringField('Publisher', validators=[DataRequired(), Length(max=100)])
    # The Publisher field requires user input, and the length is limited to 100 characters.

    genre = StringField('Genre', validators=[DataRequired(), Length(max=50)])
    # The Genre field requires user input, and the length is limited to 50 characters.

    publication_year = IntegerField('Publication Year', validators=[Optional()])
    # The Publication Year field is optional but must be a valid integer if provided.

    isbn = StringField('ISBN', validators=[Optional(), Length(max=20)])
    # The ISBN field is optional, and the length is limited to 20 characters.

    submit = SubmitField('Save')  
    # The submit button allows the user to save the form.

    # Publication Year field with validation to ensure the year is between 1000 and the current year.
    publication_year = IntegerField(
        'Publication Year', 
        validators=[
            DataRequired(),  # The field is required.
            NumberRange(min=1000, max=datetime.now().year)  # Validates the year is between 1000 and the current year.
        ]
    )
