"""
Ahmed Husain
Summary:
This Python class contains the configuration settings for the Flask application. It includes the following key settings:
1. SQLAlchemy configuration for connecting to a Microsoft SQL Server database.
2. Secret key for session management and security operations.
3. Debugging and session settings for development and production environments.
4. CSRF protection settings to secure form submissions.
5. Secure session cookies configuration to enhance security.

These settings are used by the Flask application to manage database connections, security, and session handling.
"""

import os

class Config:
    """
    Configuration class for setting up various aspects of the Flask application.
    The settings include database configurations, session management, CSRF protection, and security settings.
    """
    
    # SQLAlchemy settings
    SQLALCHEMY_DATABASE_URI = (
        'mssql+pyodbc://sa:bmoa0%2A@MANAGERONE/Ahusain_Books_Library?driver=ODBC+Driver+17+for+SQL+Server'
    )
    """
    SQLAlchemy URI for connecting to the SQL Server database.
    The format is: 'dialect+driver://username:password@host/database?driver=driver_name'.
    This connection string allows SQLAlchemy to interact with the database using the ODBC Driver for SQL Server.
    """
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False  
    """
    Disable SQLAlchemy's modification tracking feature to save resources.
    This setting prevents SQLAlchemy from keeping track of every change to objects in the session, which is not needed for most applications.
    """
    
    # Secret key for session management and other security-related operations
    SECRET_KEY = os.environ.get('SECRET_KEY', '6443f87b3ca152ef6549a9ce97f7c0ce')  
    """
    Secret key used for signing cookies and other cryptographic operations in Flask.
    It is stored in an environment variable to ensure security. If not found in the environment, it defaults to a predefined string.
    """
    
    # Additional configuration (if needed)
    DEBUG = True  
    """
    Enables or disables Flask's debugging mode. In development, this is set to True to enable automatic reloading and detailed error messages.
    It should be set to False in a production environment for better performance and security.
    """
    
    # Session settings
    SESSION_COOKIE_SECURE = True  
    """
    Ensures that the session cookie is only sent over secure HTTPS connections.
    This setting helps prevent session hijacking attacks.
    """
    
    SESSION_PERMANENT = False
    """
    Indicates whether the session is permanent. If set to False, the session will expire when the browser is closed.
    """
    
    PERMANENT_SESSION_LIFETIME = 3600  
    """
    Defines the lifetime of a permanent session in seconds. In this case, it is set to 1 hour (3600 seconds).
    """
    
    # CSRF Protection (if using forms with Flask-WTF)
    WTF_CSRF_ENABLED = True 
    """
    Enables or disables CSRF (Cross-Site Request Forgery) protection for forms submitted using Flask-WTF.
    This setting helps prevent malicious attacks by requiring a unique token for each form submission.
    """
