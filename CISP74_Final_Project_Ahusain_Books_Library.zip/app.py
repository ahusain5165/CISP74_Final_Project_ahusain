"""
Ahmed Husain, CISP74
Summary:
This Flask application is a library management system that allows admin users to perform the following tasks:
1. Admin user registration and login.
2. Display a list of books available in the library.
3. Add, edit, and delete books in the database (admin-only features).
4. Search for books using various filters such as title, author, genre, etc.
5. View detailed information about a specific book.
6. Manage user sessions with Flask-Login for secure access.
7. Use SQLAlchemy for seamless database interactions.

The application provides a web-based interface to manage books, authors, publishers, and genres in a library. 
"""

# Import necessary libraries and modules
from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config  # Custom configuration file for Flask
from models import db, Admin, Authors, BookCategories, Books, Genres, Shelves, Publishers  # Models for database interaction
from forms import RegistrationForm, LoginForm, BookForm  # Custom forms for user input validation

# Initialize the Flask application
app = Flask(__name__)
app.config.from_object(Config)  # Load app configuration from the Config class

# Bind SQLAlchemy to the Flask app for database operations
db.init_app(app)

# Set up the login manager to handle user session management
login_manager = LoginManager(app)
login_manager.login_view = 'login'  # Specify the login view for unauthorized users

# Callback function to load the current user from the database
@login_manager.user_loader
def load_user(admin_id):
    return Admin.query.get(int(admin_id))  # Retrieve the Admin user based on ID

# Route for the homepage - Displays a list of all books
@app.route('/')
def index():
    """
    Fetches all books from the database and displays them on the homepage.
    This is the main page of the application where users can see available books.
    """
    books = Books.query.all()  # Fetch all books from the database
    return render_template('index.html', books=books)  # Render the homepage with book data

# Route for registering a new admin user
@app.route('/register', methods=['GET', 'POST'])
def register():
    """
    Handles the registration of a new admin user.
    Validates the registration form and creates a new admin in the database.
    """
    form = RegistrationForm()  # Create an instance of the registration form
    if form.validate_on_submit():  # Check if form submission is valid
        new_admin = Admin(
            Name=form.Name.data,  # Assign form data to the Name field
            LoginID=form.LoginID.data,  # Assign form data to the LoginID field
            Privileges=form.Privileges.data  # Assign form data to the Privileges field
        )
        new_admin.set_password(form.Password.data)  # Hash and set the password
        db.session.add(new_admin)  # Add the new admin to the session
        db.session.commit()  # Commit changes to the database
        flash('Registration successful!', 'success')  # Show success message
        return redirect(url_for('login'))  # Redirect to the login page
    return render_template('register.html', form=form)  # Render the registration page

# Route for user login
@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Handles admin login functionality.
    Validates the login credentials and starts a user session on success.
    """
    form = LoginForm()  # Instance of the login form
    if form.validate_on_submit():  # Check if the form submission is valid
        admin = Admin.query.filter_by(LoginID=form.LoginID.data).first()  # Fetch the admin based on LoginID
        if admin and admin.check_password(form.password.data):  # Verify credentials
            login_user(admin)  # Log in the admin
            flash('Login successful!', 'success')  # Show success message
            return redirect(url_for('index'))  # Redirect to the homepage
        flash('Invalid login credentials.', 'danger')  # Show error message for invalid credentials
    return render_template('login.html', form=form)  # Render the login page

# Route for user logout
@app.route('/logout')
@login_required
def logout():
    """
    Logs out the currently logged-in admin user and redirects to the login page.
    """
    logout_user()  # Log out the current user
    flash('Logged out successfully.', 'success')  # Show success message
    return redirect(url_for('login'))  # Redirect to the login page

# Route for viewing detailed information about a specific book
@app.route('/book_info/<int:book_id>')
def book_info(book_id):
    """
    Fetches and displays detailed information about a specific book.
    Includes data about the book's author, publisher, and genre.
    """
    book = Books.query.get_or_404(book_id)  # Fetch the book or show a 404 error
    author = book.author  # Retrieve the book's author
    publisher = book.publisher  # Retrieve the book's publisher
    genre = book.genre  # Retrieve the book's genre
    return render_template('book_info.html', book=book, author=author, publisher=publisher, genre=genre)

# Route for searching books based on various filters
@app.route('/search_books', methods=['GET', 'POST'])
def search_books():
    """
    Provides a form for searching books by title, author, publisher, genre, publication year, or ISBN.
    Displays the search results on the same page.
    """
    if request.method == 'POST':  # Handle form submission
        filters = {
            'Title': request.form.get('title'),  # Get the title filter
            'AuthorID': request.form.get('author_id'),  # Get the author filter
            'PublisherID': request.form.get('publisher_id'),  # Get the publisher filter
            'GenreID': request.form.get('genre_id'),  # Get the genre filter
            'PublicationYear': request.form.get('publication_year'),  # Get the year filter
            'ISBN': request.form.get('isbn')  # Get the ISBN filter
        }

        query = Books.query  # Start building the query
        # Apply filters dynamically
        if filters['Title']:
            query = query.filter(Books.Title.ilike(f"%{filters['Title']}%"))
        if filters['AuthorID']:
            query = query.filter(Books.AuthorID == filters['AuthorID'])
        if filters['PublisherID']:
            query = query.filter(Books.PublisherID == filters['PublisherID'])
        if filters['GenreID']:
            query = query.filter(Books.GenreID == filters['GenreID'])
        if filters['PublicationYear']:
            query = query.filter(Books.PublicationYear == filters['PublicationYear'])
        if filters['ISBN']:
            query = query.filter(Books.ISBN == filters['ISBN'])

        filtered_books = query.all()  # Execute the query
        return render_template('books.html', books=filtered_books)  # Render the results page

    return render_template('search_books.html')  # Render the search form page

# Route for listing books with filters from URL parameters
@app.route('/list_books')
def list_books():
    """
    Fetches and displays a list of books based on URL query parameters for filtering.
    """
    filters = request.args.to_dict()  # Get all filter parameters from the URL
    query = Books.query  # Start building the query
    if filters:
        # Apply filters to the query
        if 'Title' in filters:
            query = query.filter(Books.Title.ilike(f"%{filters['Title']}%"))
        if 'AuthorID' in filters:
            query = query.filter(Books.AuthorID == filters['AuthorID'])
        if 'PublisherID' in filters:
            query = query.filter(Books.PublisherID == filters['PublisherID'])
        if 'GenreID' in filters:
            query = query.filter(Books.GenreID == filters['GenreID'])
        if 'PublicationYear' in filters:
            query = query.filter(Books.PublicationYear == filters['PublicationYear'])
        if 'ISBN' in filters:
            query = query.filter(Books.ISBN == filters['ISBN'])

    books = query.all()  # Execute the query
    return render_template('books.html', books=books)  # Render the list of books

# Route for adding a new book
@app.route('/add_book', methods=['GET', 'POST'])
@login_required
def add_book():
    """
    Allows admin to add a new book to the library.
    Fetches or creates the author, publisher, and genre if they don't exist.
    """
    form = BookForm()  # Create an instance of the book form
    if form.validate_on_submit():  # Check if form submission is valid
        # Fetch or create the author
        author = Authors.query.filter_by(FirstName=form.author.data).first()
        if not author:
            author = Authors(FirstName=form.author.data)
            db.session.add(author)
            db.session.commit()
            flash(f'Author "{form.author.data}" was not found and has been added.', 'info')
        
        # Fetch or create the publisher
        publisher = Publishers.query.filter_by(Name=form.publisher.data).first()
        if not publisher:
            publisher = Publishers(Name=form.publisher.data)
            db.session.add(publisher)
            db.session.commit()
            flash(f'Publisher "{form.publisher.data}" was not found and has been added.', 'info')
        
        # Fetch or create the genre
        genre = Genres.query.filter_by(GenreName=form.genre.data).first()
        if not genre:
            genre = Genres(GenreName=form.genre.data)
            db.session.add(genre)
            db.session.commit()
            flash(f'Genre "{form.genre.data}" was not found and has been added.', 'info')
        
        # Create a new book record
        new_book = Books(
            Title=form.title.data,
            AuthorID=author.AuthorID,
            PublisherID=publisher.PublisherID,
            GenreID=genre.GenreID,
            PublicationYear=form.publication_year.data,
            ISBN=form.isbn.data
        )
        db.session.add(new_book)
        db.session.commit()  # Commit changes to the database
        flash('Book added successfully!', 'success')  # Show success message
        return redirect(url_for('list_books'))  # Redirect to list of books
    return render_template('add_book.html', form=form)  # Render the add book page

# Route for editing an existing book
@app.route('/edit_book/<int:book_id>', methods=['GET', 'POST'])
@login_required
def edit_book(book_id):
    """
    Allows admin to edit the details of an existing book.
    Updates the book record with new information provided in the form.
    """
    book = Books.query.get_or_404(book_id)  # Fetch the book or show a 404 error
    form = BookForm()  # Create an instance of the book form

    if request.method == 'GET':
        # Populate form with existing book data
        form.title.data = book.Title
        form.author.data = f"{book.author.FirstName} {book.author.LastName}" if book.author else ''
        form.publisher.data = book.publisher.Name if book.publisher else ''
        form.genre.data = book.genre.GenreName if book.genre else ''
        form.publication_year.data = book.PublicationYear
        form.isbn.data = book.ISBN

    if form.validate_on_submit():  # Check if form submission is valid
        # Update book fields with form data
        author = Authors.query.filter_by(FirstName=form.author.data.split()[0]).first()
        if not author:
            flash('Invalid Author provided.', 'danger')
            return render_template('edit_book.html', form=form, book=book)

        publisher = Publishers.query.filter_by(Name=form.publisher.data).first()
        if not publisher:
            flash('Invalid Publisher provided.', 'danger')
            return render_template('edit_book.html', form=form, book=book)

        genre = Genres.query.filter_by(GenreName=form.genre.data).first()
        if not genre:
            flash('Invalid Genre provided.', 'danger')
            return render_template('edit_book.html', form=form, book=book)

        book.Title = form.title.data
        book.AuthorID = author.AuthorID
        book.PublisherID = publisher.PublisherID
        book.GenreID = genre.GenreID
        book.PublicationYear = form.publication_year.data
        book.ISBN = form.isbn.data

        db.session.commit()  # Commit changes to the database
        flash('Book details updated successfully!', 'success')  # Show success message
        return redirect(url_for('list_books'))  # Redirect to list of books

    return render_template('edit_book.html', form=form, book=book)  # Render the edit book page

# Route for deleting a book
@app.route('/delete_book/<int:book_id>', methods=['POST'])
@login_required
def delete_book(book_id):
    """
    Allows admin to delete a specific book from the library.
    Removes the book record from the database.
    """
    book = Books.query.get_or_404(book_id)  # Fetch the book or show a 404 error
    db.session.delete(book)  # Delete the book from the session
    db.session.commit()  # Commit changes to the database
    flash('Book deleted successfully!', 'success')  # Show success message
    return redirect(url_for('list_books'))  # Redirect to the list of books

# Run the application
if __name__ == '__main__':
    app.run(debug=True)  # Start the Flask development server in debug mode
