"""
Ahmed Husain
Summary:
This file serves as the entry point for running the Flask application. 
It imports the `app` instance from the `app.py` file and runs the Flask development server. 
When executed, it starts the application and makes it accessible on the local machine.
"""

# Import the app instance from the main application module (app.py)
from app import app

# Ensure that this file is being run as the main program
if __name__ == "__main__":
    """
    Runs the Flask application.
    The app.run() method starts the Flask development server.
    By default, it runs on http://127.0.0.1:5000.
    This is the entry point to start the application when the script is executed.
    """
    app.run()
