"""
Ahmed Husain
Summary:
This file defines the database extension for the Flask application. 
It initializes an instance of SQLAlchemy, which is used to interact with the database.
The `db` object will be used in the application's models to define tables and perform database operations.
"""

# Import the necessary extension from Flask to handle database interactions
from flask_sqlalchemy import SQLAlchemy

# Initialize the SQLAlchemy object, which will be used to interact with the database
db = SQLAlchemy()

"""
Explanation:
- `SQLAlchemy()` is the core extension that integrates SQLAlchemy with Flask.
- The `db` object is a Flask-SQLAlchemy instance that will be bound to the Flask app later.
- This allows you to use the `db` object to create models, query the database, and manage migrations.
"""
