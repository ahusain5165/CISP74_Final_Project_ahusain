"""
Ahmed Husain
Summary:
This file defines the data models for the Flask application using SQLAlchemy.
1. `Admin` model for managing admin user authentication, including password hashing and login validation.
2. `Authors`, `BookCategories`, `Books`, `Genres`, `Publishers`, and `Shelves` models to represent the data related to books, authors, categories, genres, publishers, and shelves in the library.
3. Foreign key relationships are defined between these tables to associate data and ensure referential integrity.

These models form the database schema, allowing interaction with the database through SQLAlchemy's ORM.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db  # Importing the initialized db object from extensions.py

# Define the Admin model with authentication support
class Admin(db.Model, UserMixin):
    """
    Admin model for managing the admin users who have access to the library system.
    The model supports authentication with password hashing and checking.
    """
    __tablename__ = 'Admin'  # Matches exactly with the SQL Server table name

    AdminID = db.Column(db.Integer, primary_key=True)  # Primary Key
    Name = db.Column(db.String(50), nullable=False)  # Full name of the Admin user
    LoginID = db.Column(db.String(50), unique=True, nullable=False)  # Unique login identifier for each Admin
    Password = db.Column(db.String(128), nullable=False)  # Hashed password for security
    Privileges = db.Column(db.String(50), nullable=True)  # Access level or role type of Admin

    def set_password(self, password):
        """Hash the password for secure storage."""
        self.Password = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if the provided password matches the stored hashed password."""
        return check_password_hash(self.Password, password)

    def get_id(self):
        """Override get_id for Flask-Login, ensuring it returns a string."""
        return str(self.AdminID)  # Flask-Login requires ID in string format

# Define the Authors table
class Authors(db.Model):
    """
    Authors model representing authors of books.
    Includes attributes such as first name, last name, birth year, and country.
    """
    __tablename__ = 'Authors'
    AuthorID = db.Column(db.Integer, primary_key=True)  # Primary Key
    FirstName = db.Column(db.String(50), nullable=True)  # Author's first name
    LastName = db.Column(db.String(50), nullable=True)  # Author's last name
    BirthYear = db.Column(db.Integer, nullable=True)  # Year of birth (optional)
    Country = db.Column(db.String(50), nullable=True)  # Author's country of origin

# Define the BookCategories table
class BookCategories(db.Model):
    """
    BookCategories model for organizing books into categories.
    """
    __tablename__ = 'BookCategories'
    CategoryID = db.Column(db.Integer, primary_key=True)  # Primary Key
    CategoryName = db.Column(db.String(50), nullable=True)  # Name of the book category

# Define the Books table
class Books(db.Model):
    """
    Books model for representing books in the library system.
    Includes attributes such as title, author, publisher, genre, category, and availability.
    """
    __tablename__ = 'Books'
    BookID = db.Column(db.Integer, primary_key=True)  # Primary Key
    Title = db.Column(db.String(100), nullable=True)  # Book title
    AuthorID = db.Column(db.Integer, db.ForeignKey('Authors.AuthorID'), nullable=True)  # Foreign Key to Authors
    PublisherID = db.Column(db.Integer, db.ForeignKey('Publishers.PublisherID'), nullable=True)  # Foreign Key to Publishers
    GenreID = db.Column(db.Integer, db.ForeignKey('Genres.GenreID'), nullable=True)  # Foreign Key to Genres
    CategoryID = db.Column(db.Integer, db.ForeignKey('BookCategories.CategoryID'), nullable=True)  # Foreign Key to BookCategories
    ShelfID = db.Column(db.Integer, db.ForeignKey('Shelves.ShelfID'), nullable=True)  # Foreign Key to Shelves
    Language = db.Column(db.String(50), nullable=True)  # Language of the book
    PublicationYear = db.Column(db.Integer, nullable=True)  # Year the book was published
    ISBN = db.Column(db.String(20), unique=True, nullable=True)  # Unique ISBN identifier
    Pages = db.Column(db.Integer, nullable=True)  # Number of pages in the book
    AvailableCopies = db.Column(db.Integer, nullable=True)  # Copies available for loan

    # Relationships
    author = db.relationship('Authors', backref=db.backref('books', lazy=True))
    publisher = db.relationship('Publishers', backref=db.backref('books', lazy=True))
    genre = db.relationship('Genres', backref=db.backref('books', lazy=True))
    category = db.relationship('BookCategories', backref=db.backref('books', lazy=True))
    shelf = db.relationship('Shelves', backref=db.backref('books', lazy=True))

# Define the Genres table
class Genres(db.Model):
    """
    Genres model to classify books by their genre.
    """
    __tablename__ = 'Genres'
    GenreID = db.Column(db.Integer, primary_key=True)  # Primary Key
    GenreName = db.Column(db.String(50), nullable=True)  # Name of the genre

# Define the Publishers table
class Publishers(db.Model):
    """
    Publishers model representing the publishers of books.
    Includes the name, country, and year of establishment for each publisher.
    """
    __tablename__ = 'Publishers'
    PublisherID = db.Column(db.Integer, primary_key=True)  # Primary Key
    Name = db.Column(db.String(100), nullable=True)  # Name of the publisher
    Country = db.Column(db.String(50), nullable=True)  # Country where the publisher is based
    EstablishedYear = db.Column(db.Integer, nullable=True)  # Year the publisher was established

# Define the Shelves table
class Shelves(db.Model):
    """
    Shelves model representing the physical or logical shelves that store books.
    """
    __tablename__ = 'Shelves'
    ShelfID = db.Column(db.Integer, primary_key=True)  # Primary Key
    ShelfName = db.Column(db.String(50), nullable=True)  # Name or identifier of the shelf
    Location = db.Column(db.String(100), nullable=True)  # Physical or logical location of the shelf
