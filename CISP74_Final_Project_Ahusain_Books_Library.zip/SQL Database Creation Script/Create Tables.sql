-- Connect to SQL Server instance MANAGERONE
-- Log in with the credentials  

-- To create the Ahusain_Books_Library database and add necessary tables, including an Admin table for authentication.

-- Step 1: Create the Database if it doesn’t already exist
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'Ahusain_Books_Library')
BEGIN
    CREATE DATABASE Ahusain_Books_Library;
END
GO

-- Use the newly created or existing database
USE Ahusain_Books_Library;
GO

-- Step 2: Create the Tables if they don’t already exist

-- Create the Authors Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Authors') AND type in (N'U'))
BEGIN
    CREATE TABLE Authors (
        AuthorID INT PRIMARY KEY IDENTITY(1,1),
        FirstName NVARCHAR(50),
        LastName NVARCHAR(50),
        BirthYear INT,
        Country NVARCHAR(50)
    );
END

-- Create the Publishers Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Publishers') AND type in (N'U'))
BEGIN
    CREATE TABLE Publishers (
        PublisherID INT PRIMARY KEY IDENTITY(1,1),
        Name NVARCHAR(100),
        Country NVARCHAR(50),
        EstablishedYear INT
    );
END

-- Create the Genres Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Genres') AND type in (N'U'))
BEGIN
    CREATE TABLE Genres (
        GenreID INT PRIMARY KEY IDENTITY(1,1),
        GenreName NVARCHAR(50)
    );
END

-- Create the BookCategories Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'BookCategories') AND type in (N'U'))
BEGIN
    CREATE TABLE BookCategories (
        CategoryID INT PRIMARY KEY IDENTITY(1,1),
        CategoryName NVARCHAR(50)
    );
END

-- Create the Shelves Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Shelves') AND type in (N'U'))
BEGIN
    CREATE TABLE Shelves (
        ShelfID INT PRIMARY KEY IDENTITY(1,1),
        ShelfName NVARCHAR(50),
        Location NVARCHAR(100)
    );
END

-- Create the Books Table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Books') AND type in (N'U'))
BEGIN
    CREATE TABLE Books (
        BookID INT PRIMARY KEY IDENTITY(1,1),
        Title NVARCHAR(100),
        AuthorID INT FOREIGN KEY REFERENCES Authors(AuthorID),
        PublisherID INT FOREIGN KEY REFERENCES Publishers(PublisherID),
        GenreID INT FOREIGN KEY REFERENCES Genres(GenreID),
        CategoryID INT FOREIGN KEY REFERENCES BookCategories(CategoryID),
        ShelfID INT FOREIGN KEY REFERENCES Shelves(ShelfID),
        Language NVARCHAR(50),
        PublicationYear INT,
        ISBN NVARCHAR(20) UNIQUE,
        Pages INT,
        AvailableCopies INT DEFAULT 1
    );
END

-- Create the Admin Table for Login and Privileges
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Admin') AND type in (N'U'))
BEGIN
    CREATE TABLE Admin (
        AdminID INT PRIMARY KEY IDENTITY(1,1),
        Name NVARCHAR(50),
        LoginID NVARCHAR(50) UNIQUE,
        Password NVARCHAR(150),  -- Store a hashed password for security
        Privileges NVARCHAR(50)  -- Define privileges like 'edit', 'delete', 'read', 'full control'
    );
END

-- Step 3: Sample Insert Statements (Optional)

-- Sample Admin Entries
IF NOT EXISTS (SELECT * FROM Admin)
BEGIN
    INSERT INTO Admin (Name, LoginID, Password, Privileges)
    VALUES 
        ('AdminUser1', 'admin1', HASHBYTES('SHA2_256', 'password123'), 'full control'),
		('AdminUser2', 'ahusain', HASHBYTES('SHA2_256', 'bmoa0*'), 'full control'),
        ('EditorUser', 'editor', HASHBYTES('SHA2_256', 'password456'), 'edit, delete, read');
END

-- Sample Authors
IF NOT EXISTS (SELECT * FROM Authors)
BEGIN
    INSERT INTO Authors (FirstName, LastName, BirthYear, Country)
    VALUES ('George', 'Orwell', 1903, 'United Kingdom'),
           ('Jane', 'Austen', 1775, 'United Kingdom');
END

-- Sample Publishers
IF NOT EXISTS (SELECT * FROM Publishers)
BEGIN
    INSERT INTO Publishers (Name, Country, EstablishedYear)
    VALUES ('Penguin Books', 'United Kingdom', 1935),
           ('HarperCollins', 'United States', 1989);
END

-- Sample Genres
IF NOT EXISTS (SELECT * FROM Genres)
BEGIN
    INSERT INTO Genres (GenreName)
    VALUES ('Science Fiction'), ('Romance'), ('Mystery'), ('Non-Fiction');
END

-- Sample Categories
IF NOT EXISTS (SELECT * FROM BookCategories)
BEGIN
    INSERT INTO BookCategories (CategoryName)
    VALUES ('Literature'), ('Children'), ('Science'), ('History');
END

-- Sample Shelves
IF NOT EXISTS (SELECT * FROM Shelves)
BEGIN
    INSERT INTO Shelves (ShelfName, Location)
    VALUES ('Shelf A1', 'Floor 1, Section A'), ('Shelf B1', 'Floor 1, Section B');
END

-- Sample Books
IF NOT EXISTS (SELECT * FROM Books)
BEGIN
    INSERT INTO Books (Title, AuthorID, PublisherID, GenreID, CategoryID, ShelfID, Language, PublicationYear, ISBN, Pages, AvailableCopies)
    VALUES ('1984', 1, 1, 1, 1, 1, 'English', 1949, '9780451524935', 328, 5),
           ('Pride and Prejudice', 2, 2, 2, 1, 2, 'English', 1813, '9780141199078', 279, 2);
END

GO
